
/*
document.addEventListener("DOMContentLoaded", () => {
    const getAllInfoBtn = document.getElementById("getAllInfoBtn");
    const studentIdInput = document.getElementById("studentId");
    const validationMessage = document.getElementById("validationMessage");
    const scheduleResponse = document.getElementById("scheduleResponse");
    const absentResponse = document.getElementById("absentResponse");
    const studentInfoContainer = document.querySelector(".promo_card");

    getAllInfoBtn.addEventListener("click", async (event) => {
        if (!validateStudentId()) {
            event.preventDefault();
            return;
        }

        const studentId = studentIdInput.value.trim();

        try {
            const combinedInfo = await fetchCombinedInfo(studentId);

            displayStudentInfo(combinedInfo.studentInfo);
            displayScheduleInfo(combinedInfo.scheduleInfo);
            displayAbsentInfo(combinedInfo.absentInfo);
        } catch (error) {
            console.error("Error fetching data:", error);
            validationMessage.textContent = "Error fetching data. Please try again.";
        }
    });

    studentIdInput.addEventListener("input", () => {
        validateStudentId();
    });

    function validateStudentId() {
        const studentIdValue = studentIdInput.value.trim();
        if (studentIdValue === "") {
            validationMessage.textContent = "Student ID cannot be empty.";
            return false;
        } else if (isNaN(studentIdValue)) {
            validationMessage.textContent = "Student ID must be a numeric value.";
            return false;
        } else if (studentIdValue.length !== 7) {
            validationMessage.textContent = "Student ID must be exactly 7 digits long.";
            return false;
        } else {
            validationMessage.textContent = "";
            return true;
        }
    }

    // async function fetchCombinedInfo(studentId) {
    //     const response = await fetch(`http://localhost:5062/studentController/StudentData/?${studentId}`);
    //     if (!response.ok) {
    //         throw new Error("Failed to fetch combined info");
    //     }
    //     return response.json();
    // }

     async function fetchCombinedInfo(studentId) {
        const [studentResponse, scheduleResponse, absentResponse] = await Promise.all([
            fetch('http://localhost:5062/studentController/StudentData/?${studentId}'),
            fetch('http://localhost:5062/studentController/ScheduleData/?${studentId}'),
            fetch('http://localhost:5062/studentController/AbsentData/?${studentId}')
        ]);

        if (!studentResponse.ok || !scheduleResponse.ok || !absentResponse.ok) {
            throw new Error("Failed to fetch combined info");
        }

        const studentInfo = await studentResponse.json();
        const scheduleInfo = await scheduleResponse.json();
        const absentInfo = await absentResponse.json();

        return {
            studentInfo,
            scheduleInfo,
            absentInfo
        };
    }


    function displayStudentInfo(info) {

        console.log(info);
        /*sstudentInfoContainer.querySelector("StudentNoData").innerHTML = `Student No: ${info.studentNo}`;
        tudentInfoContainer.querySelector("h3:nth-of-type(2)").innerHTML = `Student PIDM: ${info.studentPIDM}`;
        studentInfoContainer.querySelector("h3:nth-of-type(3)").innerHTML = `Full Name: ${info.fullName}`;
        studentInfoContainer.querySelector("h3:nth-of-type(4)").innerHTML = `ID Number: ${info.idNumber}`;
        studentInfoContainer.querySelector("h3:nth-of-type(5)").innerHTML = `College: ${info.college}`;
        studentInfoContainer.querySelector("h3:nth-of-type(6)").innerHTML = `Campus Title: ${info.campusTitle}`;
        studentInfoContainer.querySelector("h3:nth-of-type(7)").innerHTML = `Dept Title: ${info.deptTitle}`;
        studentInfoContainer.querySelector("h3:nth-of-type(8)").innerHTML = `Status: ${info.status}`;
        
    }

    function displayScheduleInfo(info) {
        const tbody = scheduleResponse.querySelector("tbody");
        tbody.innerHTML = `
            <tr>
                <td>1</td>
                <td>${info.term}</td>
                <td>${info.name}</td>
                <td>${info.dept}</td>
                <td>${info.course_No}</td>
                <td>${info.section}</td>
                <td>${info.crn}</td>
                <td>${info.instructor_ID}</td>
                <td>${info.teacherName}</td>
                <td>${info.status}</td>
                <td>${info.lastModificationDate}</td>
                <td>${info.addedDate}</td>
                <td>${info.sectionSchedule}</td>
                <td>${info.time}</td>
            </tr>`;
    }

    function displayAbsentInfo(info) {
        const tbody = absentResponse.querySelector("tbody");
        tbody.innerHTML = `
            <tr>
                <td>${info.term}</td>
                <td>${info.crn}</td>
                <td>${info.course}</td>
                <td>${info.title}</td>
                <td>${info.section}</td>
                <td>${info.absentCount}</td>
                <td>${info.days}</td>
            </tr>`;
    }
});

*/
