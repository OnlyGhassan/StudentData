function adjustBackgroundColor() {
    const width = window.innerWidth;
    if (width < 600) {
        document.body.style.backgroundColor = 'rgb(219, 219, 219)';
    } else if (width < 900) {
        document.body.style.backgroundColor = 'rgb(219, 219, 219)';
    } else {
        document.body.style.backgroundColor = 'rgb(219, 219, 219)';
    }
}

window.addEventListener('resize', adjustBackgroundColor);
window.addEventListener('load', adjustBackgroundColor);



document.addEventListener("DOMContentLoaded", () => {
    const studentLink = document.getElementById("studentLink");
    const instructorLink = document.getElementById("instructorLink");
    const getAllInfoBtn = document.getElementById("getAllInfoBtn");
    const loadingSpinner = document.getElementById("loadingSpinner");
    const studentIdInput = document.getElementById("studentId");
    const validationMessage = document.getElementById("validationMessage");
    const scheduleResponse = document.getElementById("scheduleResponse");
    const absentResponse = document.getElementById("absentResponse");
  
    studentLink.addEventListener("click", () => {
      studentLink.classList.add("active");
      instructorLink.classList.remove("active");
    });
  
    instructorLink.addEventListener("click", () => {
      instructorLink.classList.add("active");
      studentLink.classList.remove("active");
    });
  
    getAllInfoBtn.addEventListener("click", (event) => {
      if (!validateStudentId()) {
        event.preventDefault();
        return;
      }
  
      loadingSpinner.style.display = "block";
      scheduleResponse.classList.add("hidden");
      absentResponse.classList.add("hidden");
  
      setTimeout(() => {
        loadingSpinner.style.display = "none";
        scheduleResponse.classList.remove("hidden");
        absentResponse.classList.remove("hidden");
      }, 2000);
    });
  
    studentIdInput.addEventListener("input", () => {
      validateStudentId();
    });
  
    function validateStudentId() {
      const studentIdValue = studentIdInput.value.trim();
      if (studentIdValue === "") {
        validationMessage.textContent = "Student ID cannot be empty.";
        return false;
      } else if (isNaN(studentIdValue)) {
        validationMessage.textContent = "Student ID must be a numeric value.";
        return false;
      } else if (studentIdValue.length !== 7) {
        validationMessage.textContent = "Student ID must be exactly 7 digits long.";
        return false;
      } else {
        validationMessage.textContent = "";
        return true;
      }
    }
  });
  


