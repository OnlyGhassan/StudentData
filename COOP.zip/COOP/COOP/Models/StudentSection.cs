﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace COOP.Models;

public partial class StudentSection
{
    [Column("SFRSTCR_TERM_CODE")]
    [StringLength(6)]
    public string SfrstcrTermCode { get; set; } = null!;

    [Column("SFRSTCR_PIDM", TypeName = "numeric(8, 0)")]
    public decimal SfrstcrPidm { get; set; }

    [Column("SFRSTCR_CRN")]
    [StringLength(5)]
    public string SfrstcrCrn { get; set; } = null!;

    [Column("SFRSTCR_CLASS_SORT_KEY", TypeName = "numeric(4, 0)")]
    public decimal? SfrstcrClassSortKey { get; set; }

    [Column("SFRSTCR_REG_SEQ", TypeName = "numeric(4, 0)")]
    public decimal SfrstcrRegSeq { get; set; }

    [Column("SFRSTCR_PTRM_CODE")]
    [StringLength(3)]
    public string? SfrstcrPtrmCode { get; set; }

    [Column("SFRSTCR_RSTS_CODE")]
    [StringLength(2)]
    public string? SfrstcrRstsCode { get; set; }

    [Column("SFRSTCR_RSTS_DATE", TypeName = "datetime")]
    public DateTime? SfrstcrRstsDate { get; set; }

    [Column("SFRSTCR_ERROR_FLAG")]
    [StringLength(1)]
    public string? SfrstcrErrorFlag { get; set; }

    [Column("SFRSTCR_MESSAGE")]
    [StringLength(200)]
    public string? SfrstcrMessage { get; set; }

    [Column("SFRSTCR_BILL_HR", TypeName = "numeric(7, 3)")]
    public decimal? SfrstcrBillHr { get; set; }

    [Column("SFRSTCR_WAIV_HR", TypeName = "numeric(7, 3)")]
    public decimal? SfrstcrWaivHr { get; set; }

    [Column("SFRSTCR_CREDIT_HR", TypeName = "numeric(7, 3)")]
    public decimal? SfrstcrCreditHr { get; set; }

    [Column("SFRSTCR_BILL_HR_HOLD", TypeName = "numeric(7, 3)")]
    public decimal? SfrstcrBillHrHold { get; set; }

    [Column("SFRSTCR_CREDIT_HR_HOLD", TypeName = "numeric(7, 3)")]
    public decimal? SfrstcrCreditHrHold { get; set; }

    [Column("SFRSTCR_GMOD_CODE")]
    [StringLength(1)]
    public string? SfrstcrGmodCode { get; set; }

    [Column("SFRSTCR_GRDE_CODE")]
    [StringLength(6)]
    public string? SfrstcrGrdeCode { get; set; }

    [Column("SFRSTCR_GRDE_CODE_MID")]
    [StringLength(6)]
    public string? SfrstcrGrdeCodeMid { get; set; }

    [Column("SFRSTCR_GRDE_DATE", TypeName = "datetime")]
    public DateTime? SfrstcrGrdeDate { get; set; }

    [Column("SFRSTCR_DUPL_OVER")]
    [StringLength(1)]
    public string? SfrstcrDuplOver { get; set; }

    [Column("SFRSTCR_LINK_OVER")]
    [StringLength(1)]
    public string? SfrstcrLinkOver { get; set; }

    [Column("SFRSTCR_CORQ_OVER")]
    [StringLength(1)]
    public string? SfrstcrCorqOver { get; set; }

    [Column("SFRSTCR_PREQ_OVER")]
    [StringLength(1)]
    public string? SfrstcrPreqOver { get; set; }

    [Column("SFRSTCR_TIME_OVER")]
    [StringLength(1)]
    public string? SfrstcrTimeOver { get; set; }

    [Column("SFRSTCR_CAPC_OVER")]
    [StringLength(1)]
    public string? SfrstcrCapcOver { get; set; }

    [Column("SFRSTCR_LEVL_OVER")]
    [StringLength(1)]
    public string? SfrstcrLevlOver { get; set; }

    [Column("SFRSTCR_COLL_OVER")]
    [StringLength(1)]
    public string? SfrstcrCollOver { get; set; }

    [Column("SFRSTCR_MAJR_OVER")]
    [StringLength(1)]
    public string? SfrstcrMajrOver { get; set; }

    [Column("SFRSTCR_CLAS_OVER")]
    [StringLength(1)]
    public string? SfrstcrClasOver { get; set; }

    [Column("SFRSTCR_APPR_OVER")]
    [StringLength(1)]
    public string? SfrstcrApprOver { get; set; }

    [Column("SFRSTCR_APPR_RECEIVED_IND")]
    [StringLength(1)]
    public string? SfrstcrApprReceivedInd { get; set; }

    [Column("SFRSTCR_ADD_DATE", TypeName = "datetime")]
    public DateTime SfrstcrAddDate { get; set; }

    [Column("SFRSTCR_ACTIVITY_DATE", TypeName = "datetime")]
    public DateTime SfrstcrActivityDate { get; set; }

    [Column("SFRSTCR_LEVL_CODE")]
    [StringLength(2)]
    public string SfrstcrLevlCode { get; set; } = null!;

    [Column("SFRSTCR_CAMP_CODE")]
    [StringLength(3)]
    public string SfrstcrCampCode { get; set; } = null!;

    [Column("SFRSTCR_RESERVED_KEY")]
    [StringLength(82)]
    public string? SfrstcrReservedKey { get; set; }

    [Column("SFRSTCR_ATTEND_HR", TypeName = "numeric(9, 3)")]
    public decimal? SfrstcrAttendHr { get; set; }

    [Column("SFRSTCR_REPT_OVER")]
    [StringLength(1)]
    public string? SfrstcrReptOver { get; set; }

    [Column("SFRSTCR_RPTH_OVER")]
    [StringLength(1)]
    public string? SfrstcrRpthOver { get; set; }

    [Column("SFRSTCR_TEST_OVER")]
    [StringLength(1)]
    public string? SfrstcrTestOver { get; set; }

    [Column("SFRSTCR_CAMP_OVER")]
    [StringLength(1)]
    public string? SfrstcrCampOver { get; set; }

    [Column("SFRSTCR_USER")]
    [StringLength(30)]
    public string? SfrstcrUser { get; set; }

    [Column("SFRSTCR_DEGC_OVER")]
    [StringLength(1)]
    public string? SfrstcrDegcOver { get; set; }

    [Column("SFRSTCR_PROG_OVER")]
    [StringLength(1)]
    public string? SfrstcrProgOver { get; set; }

    [Column("SFRSTCR_LAST_ATTEND", TypeName = "datetime")]
    public DateTime? SfrstcrLastAttend { get; set; }

    [Column("SFRSTCR_GCMT_CODE")]
    [StringLength(7)]
    public string? SfrstcrGcmtCode { get; set; }

    [Column("SFRSTCR_DATA_ORIGIN")]
    [StringLength(30)]
    public string? SfrstcrDataOrigin { get; set; }

    [Column("SFRSTCR_ASSESS_ACTIVITY_DATE", TypeName = "datetime")]
    public DateTime? SfrstcrAssessActivityDate { get; set; }

    [Column("SFRSTCR_DEPT_OVER")]
    [StringLength(1)]
    public string? SfrstcrDeptOver { get; set; }

    [Column("SFRSTCR_ATTS_OVER")]
    [StringLength(1)]
    public string? SfrstcrAttsOver { get; set; }

    [Column("SFRSTCR_CHRT_OVER")]
    [StringLength(1)]
    public string? SfrstcrChrtOver { get; set; }

    [Column("SFRSTCR_RMSG_CDE")]
    [StringLength(4)]
    public string? SfrstcrRmsgCde { get; set; }

    [Column("SFRSTCR_WL_PRIORITY", TypeName = "numeric(11, 6)")]
    public decimal? SfrstcrWlPriority { get; set; }

    [Column("SFRSTCR_WL_PRIORITY_ORIG")]
    [StringLength(1)]
    public string? SfrstcrWlPriorityOrig { get; set; }

    [Column("SFRSTCR_GRDE_CODE_INCMP_FINAL")]
    [StringLength(6)]
    public string? SfrstcrGrdeCodeIncmpFinal { get; set; }

    [Column("SFRSTCR_INCOMPLETE_EXT_DATE", TypeName = "datetime")]
    public DateTime? SfrstcrIncompleteExtDate { get; set; }

    [Column("SFRSTCR_MEXC_OVER")]
    [StringLength(1)]
    public string? SfrstcrMexcOver { get; set; }

    [Key]
    public long Id { get; set; }
}
