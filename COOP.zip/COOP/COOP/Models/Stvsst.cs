﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace COOP.Models;

[Keyless]
[Table("STVSSTS")]
public partial class Stvsst
{
    [Column("STVSSTS_CODE")]
    [StringLength(1)]
    public string StvsstsCode { get; set; } = null!;

    [Column("STVSSTS_DESC")]
    [StringLength(30)]
    public string StvsstsDesc { get; set; } = null!;

    [Column("STVSSTS_REG_IND")]
    [StringLength(1)]
    public string StvsstsRegInd { get; set; } = null!;

    [Column("STVSSTS_ACTIVITY_DATE", TypeName = "datetime")]
    public DateTime StvsstsActivityDate { get; set; }

    [Column("STVSSTS_ACTIVE_IND")]
    [StringLength(1)]
    public string StvsstsActiveInd { get; set; } = null!;
}
