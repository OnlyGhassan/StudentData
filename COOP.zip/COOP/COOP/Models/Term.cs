﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace COOP.Models;

[Table("Term")]
public partial class Term
{
    [Key]
    public int Id { get; set; }

    [StringLength(50)]
    public string Name { get; set; } = null!;

    [Column("TYear")]
    [StringLength(50)]
    public string Tyear { get; set; } = null!;

    [StringLength(50)]
    public string Num { get; set; } = null!;

    [StringLength(50)]
    public string Title { get; set; } = null!;

    public bool IsCur { get; set; }

    [StringLength(50)]
    public string? ArTitle { get; set; }

    [StringLength(50)]
    public string? EnTitle { get; set; }

    [Column("ARYears")]
    [StringLength(50)]
    public string? Aryears { get; set; }

    [Column("ENYears")]
    [StringLength(50)]
    public string? Enyears { get; set; }

    [Column("NAMEAR")]
    [StringLength(50)]
    public string? Namear { get; set; }

    [Column("DESCRIPTION")]
    [StringLength(50)]
    public string? Description { get; set; }

    [Column("START_DATE")]
    [StringLength(50)]
    public string? StartDate { get; set; }

    [Column("END_DATE")]
    [StringLength(50)]
    public string? EndDate { get; set; }

    [Column("NEW_DATA_SOURCE_KEY")]
    [StringLength(50)]
    public string? NewDataSourceKey { get; set; }

    [Column("BB_TermID")]
    [StringLength(50)]
    public string? BbTermId { get; set; }
}
