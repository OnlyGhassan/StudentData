﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace COOP.Models;

[Keyless]
public partial class DoctorDatum
{
    [Column("SPRIDEN_PIDM", TypeName = "numeric(8, 0)")]
    public decimal SpridenPidm { get; set; }

    [Column("SPRIDEN_ID")]
    [StringLength(9)]
    public string SpridenId { get; set; } = null!;

    [Column("SPRIDEN_FIRST_NAME")]
    [StringLength(60)]
    public string? SpridenFirstName { get; set; }

    [Column("SPRIDEN_MI")]
    [StringLength(60)]
    public string? SpridenMi { get; set; }

    [Column("SPRIDEN_LAST_NAME")]
    [StringLength(60)]
    public string SpridenLastName { get; set; } = null!;

    [Column("SIBINST_PIDM", TypeName = "numeric(8, 0)")]
    public decimal SibinstPidm { get; set; }

    [Column("SIBINST_TERM_CODE_EFF")]
    [StringLength(6)]
    public string SibinstTermCodeEff { get; set; } = null!;

    [Column("SIBINST_FCST_CODE")]
    [StringLength(2)]
    public string SibinstFcstCode { get; set; } = null!;

    [Column("SIBINST_FCTG_CODE")]
    [StringLength(6)]
    public string? SibinstFctgCode { get; set; }

    [Column("SIBINST_FSTP_CODE")]
    [StringLength(4)]
    public string? SibinstFstpCode { get; set; }

    [Column("SIBINST_FCNT_CODE")]
    [StringLength(2)]
    public string? SibinstFcntCode { get; set; }

    [Column("SIBINST_SCHD_IND")]
    [StringLength(1)]
    public string? SibinstSchdInd { get; set; }

    [Column("SIBINST_ADVR_IND")]
    [StringLength(1)]
    public string? SibinstAdvrInd { get; set; }

    [Column("SIBINST_FCST_DATE", TypeName = "datetime")]
    public DateTime SibinstFcstDate { get; set; }

    [Column("SIBINST_WKLD_CODE")]
    [StringLength(6)]
    public string? SibinstWkldCode { get; set; }

    [Column("SIBINST_CNTR_CODE")]
    [StringLength(6)]
    public string? SibinstCntrCode { get; set; }

    [Column("SIBINST_APPOINT_DATE", TypeName = "datetime")]
    public DateTime? SibinstAppointDate { get; set; }

    [Column("SIBINST_ACTIVITY_DATE", TypeName = "datetime")]
    public DateTime SibinstActivityDate { get; set; }

    [Column("SIBINST_DATA_ORIGIN")]
    [StringLength(30)]
    public string? SibinstDataOrigin { get; set; }

    [Column("SIBINST_USER_ID")]
    [StringLength(30)]
    public string? SibinstUserId { get; set; }

    [Column("EMAIL")]
    [StringLength(300)]
    public string? Email { get; set; }

    [Column("M_PHONE")]
    [StringLength(300)]
    public string? MPhone { get; set; }

    [Column("COLL")]
    [StringLength(6)]
    public string? Coll { get; set; }

    [Column("DEPT")]
    [StringLength(6)]
    public string? Dept { get; set; }

    [Column("SPBPERS_SSN")]
    [StringLength(15)]
    public string? SpbpersSsn { get; set; }

    [Column("SPBPERS_BIRTH_DATE", TypeName = "datetime")]
    public DateTime? SpbpersBirthDate { get; set; }

    [Column("SPBPERS_SEX")]
    [StringLength(1)]
    public string? SpbpersSex { get; set; }
}
