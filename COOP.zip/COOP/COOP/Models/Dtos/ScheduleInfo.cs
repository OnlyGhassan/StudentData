using System.Text.Json.Serialization;

namespace COOP.Models;

public class ScheduleInfo
{
    public DateOnly? Term { get; set; } // may change DateOnly TODO
    public String? Name { get; set; }
    public String? Dept { get; set; }
    public String? Course_No { get; set; }
    public String? Section { get; set; }
    public String? CRN { get; set; }
    public String? Instructor_ID { get; set; }
    public String? TeacherName { get; set; }
    public String? Status { get; set; } // may change

    // Internal properties to hold DateTime values
    // the JsonIgnore is used so it doesnt show the data twice in the api.

    [JsonIgnore]
    public DateTime? LastModificationDate { get; set; }

    [JsonIgnore]
    public DateTime? AddedDate { get; set; }

    [JsonIgnore]
    public DateTime? SectionSchedule { get; set; }

    [JsonIgnore]
    public DateTime? Time { get; set; }

    // Properties to return formatted values
    // modifying the date data so it show the same way in the interface.
    public string? LastModificationDateFormatted => LastModificationDate?.ToString("MM/dd/yyyy h:mm:ss tt");
    public string? AddedDateFormatted => AddedDate?.ToString("MM/dd/yyyy h:mm:ss tt");
    public string? SectionScheduleDay => SectionSchedule?.DayOfWeek.ToString();
    public string? TimeFormatted => Time.HasValue ? $"{Time.Value:HHmm} to {Time.Value.AddMinutes(80):HHmm}" : null;

}