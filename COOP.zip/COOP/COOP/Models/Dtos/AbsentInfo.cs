using System.Text.Json.Serialization;

namespace COOP;

public class AbsentInfo
{
    [JsonIgnore]
    public DateTime? Term { get; set; }
    public String? TermFormat => Term?.ToString("yyyyMM");
    public String? Crn { get; set; }
    public String? Course { get; set; }
    public String? Title { get; set; }
    public String? Section { get; set; }
    public int? AbsentCount { get; set; }
    public DateTime? DAYS { get; set; }
}