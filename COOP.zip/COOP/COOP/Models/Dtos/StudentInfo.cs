using System.Text.Json.Serialization;

namespace COOP.Models;

public class StudentInfo
{
    [JsonIgnore]
    public DateTime? Term { get; set; }
    public string? TermFormat => Term?.ToString("yyyyMM");

    public String? StudentID { get; set; }
    public String? StudentNo { get; set; }
    public String? StudentPIDM { get; set; }
    public String? FullName { get; set; }
    public String? IDNumber { get; set; }
    public String? College { get; set; }
    public String? CampusTitle { get; set; }
    public String? DeptTitle { get; set; }
    public String? Status { get; set; } // may change 

}