﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace COOP.Models;

[Keyless]
[Table("STVSCHD")]
public partial class Stvschd
{
    [Column("STVSCHD_CODE")]
    [StringLength(2)]
    public string StvschdCode { get; set; } = null!;

    [Column("STVSCHD_DESC")]
    [StringLength(200)]
    public string StvschdDesc { get; set; } = null!;

    [Column("STVSCHD_ACTIVITY_DATE", TypeName = "datetime")]
    public DateTime StvschdActivityDate { get; set; }

    [Column("STVSCHD_INSTRUCT_METHOD")]
    [StringLength(200)]
    public string? StvschdInstructMethod { get; set; }

    [Column("STVSCHD_COOP_IND")]
    [StringLength(200)]
    public string? StvschdCoopInd { get; set; }

    [Column("asSTVSCHD_AUTO_SCHEDULER_IND")]
    [StringLength(200)]
    public string? AsStvschdAutoSchedulerInd { get; set; }

    [Column("STVSCHD_INSM_CODE")]
    [StringLength(200)]
    public string? StvschdInsmCode { get; set; }

    [Column("STVSCHD_VR_MSG_NO")]
    public int? StvschdVrMsgNo { get; set; }
}
