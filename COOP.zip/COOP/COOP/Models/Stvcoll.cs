﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace COOP.Models;

[Keyless]
[Table("STVCOLL")]
public partial class Stvcoll
{
    [Column("STVCOLL_CODE")]
    [StringLength(2)]
    public string StvcollCode { get; set; } = null!;

    [Column("STVCOLL_DESC")]
    [StringLength(30)]
    public string StvcollDesc { get; set; } = null!;

    [Column("STVCOLL_ADDR_STREET_LINE1")]
    [StringLength(75)]
    public string? StvcollAddrStreetLine1 { get; set; }

    [Column("STVCOLL_ADDR_STREET_LINE2")]
    [StringLength(75)]
    public string? StvcollAddrStreetLine2 { get; set; }

    [Column("STVCOLL_ADDR_STREET_LINE3")]
    [StringLength(75)]
    public string? StvcollAddrStreetLine3 { get; set; }

    [Column("STVCOLL_ADDR_CITY")]
    [StringLength(50)]
    public string? StvcollAddrCity { get; set; }

    [Column("STVCOLL_ADDR_STATE")]
    [StringLength(2)]
    public string? StvcollAddrState { get; set; }

    [Column("STVCOLL_ADDR_COUNTRY")]
    [StringLength(28)]
    public string? StvcollAddrCountry { get; set; }

    [Column("STVCOLL_ADDR_ZIP_CODE")]
    [StringLength(10)]
    public string? StvcollAddrZipCode { get; set; }

    [Column("STVCOLL_ACTIVITY_DATE", TypeName = "datetime")]
    public DateTime? StvcollActivityDate { get; set; }

    [Column("STVCOLL_SYSTEM_REQ_IND")]
    [StringLength(1)]
    public string? StvcollSystemReqInd { get; set; }

    [Column("STVCOLL_VR_MSG_NO", TypeName = "numeric(6, 0)")]
    public decimal? StvcollVrMsgNo { get; set; }

    [Column("STVCOLL_STATSCAN_CDE3")]
    [StringLength(6)]
    public string? StvcollStatscanCde3 { get; set; }

    [Column("STVCOLL_DICD_CODE")]
    [StringLength(3)]
    public string? StvcollDicdCode { get; set; }

    [Column("STVCOLL_HOUSE_NUMBER")]
    [StringLength(10)]
    public string? StvcollHouseNumber { get; set; }

    [Column("STVCOLL_ADDR_STREET_LINE4")]
    [StringLength(75)]
    public string? StvcollAddrStreetLine4 { get; set; }
}
