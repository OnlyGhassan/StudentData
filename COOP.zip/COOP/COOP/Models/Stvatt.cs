﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace COOP.Models;

[Keyless]
[Table("STVATTS")]
public partial class Stvatt
{
    [Column("STVATTS_CODE")]
    [StringLength(4)]
    public string StvattsCode { get; set; } = null!;

    [Column("STVATTS_DESC")]
    [StringLength(30)]
    public string StvattsDesc { get; set; } = null!;

    [Column("STVATTS_ACTIVITY_DATE", TypeName = "datetime")]
    public DateTime StvattsActivityDate { get; set; }
}
