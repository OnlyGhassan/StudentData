﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace COOP.Models;

[Keyless]
[Table("STVRSTS")]
public partial class Stvrst
{
    [Column("STVRSTS_CODE")]
    [StringLength(2)]
    public string StvrstsCode { get; set; } = null!;

    [Column("STVRSTS_DESC")]
    [StringLength(30)]
    public string StvrstsDesc { get; set; } = null!;

    [Column("STVRSTS_ENTERABLE_IND")]
    [StringLength(1)]
    public string StvrstsEnterableInd { get; set; } = null!;

    [Column("STVRSTS_INCL_SECT_ENRL")]
    [StringLength(1)]
    public string StvrstsInclSectEnrl { get; set; } = null!;

    [Column("STVRSTS_INCL_ASSESS")]
    [StringLength(1)]
    public string StvrstsInclAssess { get; set; } = null!;

    [Column("STVRSTS_AUTO_GRADE")]
    [StringLength(6)]
    public string? StvrstsAutoGrade { get; set; }

    [Column("STVRSTS_GRADABLE_IND")]
    [StringLength(1)]
    public string StvrstsGradableInd { get; set; } = null!;

    [Column("STVRSTS_ACTIVITY_DATE", TypeName = "datetime")]
    public DateTime StvrstsActivityDate { get; set; }

    [Column("STVRSTS_WAIT_IND")]
    [StringLength(1)]
    public string StvrstsWaitInd { get; set; } = null!;

    [Column("STVRSTS_SYSTEM_REQ_IND")]
    [StringLength(1)]
    public string? StvrstsSystemReqInd { get; set; }

    [Column("STVRSTS_VOICE_TYPE")]
    [StringLength(1)]
    public string? StvrstsVoiceType { get; set; }

    [Column("STVRSTS_SB_PRINT_IND")]
    [StringLength(1)]
    public string? StvrstsSbPrintInd { get; set; }

    [Column("STVRSTS_WITHDRAW_IND")]
    [StringLength(1)]
    public string StvrstsWithdrawInd { get; set; } = null!;

    [Column("STVRSTS_WEB_IND")]
    [StringLength(1)]
    public string StvrstsWebInd { get; set; } = null!;

    [Column("STVRSTS_EXTENSION_IND")]
    [StringLength(1)]
    public string StvrstsExtensionInd { get; set; } = null!;

    [Column("STVRSTS_ATTEMPT_HR_IND")]
    [StringLength(1)]
    public string StvrstsAttemptHrInd { get; set; } = null!;

    [Column("STVRSTS_INCL_TMST_IND")]
    [StringLength(1)]
    public string StvrstsInclTmstInd { get; set; } = null!;
}
