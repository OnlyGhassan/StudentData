﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace COOP.Models;

[Keyless]
public partial class StudentDatum
{
    [Column("SPRIDEN_PIDM", TypeName = "numeric(8, 0)")]
    public decimal SpridenPidm { get; set; }

    [Column("SPRIDEN_ID")]
    [StringLength(9)]
    public string SpridenId { get; set; } = null!;

    [Column("SPRIDEN_FIRST_NAME")]
    [StringLength(60)]
    public string? SpridenFirstName { get; set; }

    [Column("SPRIDEN_MI")]
    [StringLength(60)]
    public string? SpridenMi { get; set; }

    [Column("SPRIDEN_LAST_NAME")]
    [StringLength(60)]
    public string? SpridenLastName { get; set; }

    [Column("SGBSTDN_TERM_CODE_EFF")]
    [StringLength(6)]
    public string? SgbstdnTermCodeEff { get; set; }

    [Column("SGBSTDN_STST_CODE")]
    [StringLength(2)]
    public string? SgbstdnStstCode { get; set; }

    [Column("SGBSTDN_LEVL_CODE")]
    [StringLength(2)]
    public string? SgbstdnLevlCode { get; set; }

    [Column("SGBSTDN_STYP_CODE")]
    [StringLength(1)]
    public string? SgbstdnStypCode { get; set; }

    [Column("SGBSTDN_CAMP_CODE")]
    [StringLength(3)]
    public string? SgbstdnCampCode { get; set; }

    [Column("SGBSTDN_RESD_CODE")]
    [StringLength(1)]
    public string? SgbstdnResdCode { get; set; }

    [Column("SGBSTDN_COLL_CODE_1")]
    [StringLength(2)]
    public string? SgbstdnCollCode1 { get; set; }

    [Column("SGBSTDN_ADMT_CODE")]
    [StringLength(2)]
    public string? SgbstdnAdmtCode { get; set; }

    [Column("SGBSTDN_DEPT_CODE")]
    [StringLength(4)]
    public string? SgbstdnDeptCode { get; set; }

    [Column("SPBPERS_SSN")]
    [StringLength(15)]
    public string? SpbpersSsn { get; set; }

    [Column("SPBPERS_BIRTH_DATE", TypeName = "datetime")]
    public DateTime? SpbpersBirthDate { get; set; }

    [Column("SPBPERS_SEX")]
    [StringLength(1)]
    public string? SpbpersSex { get; set; }

    [Column("SGBSTDN_PIDM", TypeName = "numeric(8, 0)")]
    public decimal? SgbstdnPidm { get; set; }

    [Column("SGRSATT_PIDM", TypeName = "numeric(8, 0)")]
    public decimal? SgrsattPidm { get; set; }

    [Column("SGRSATT_TERM_CODE_EFF")]
    [StringLength(6)]
    public string? SgrsattTermCodeEff { get; set; }

    [Column("SGRSATT_ATTS_CODE")]
    [StringLength(4)]
    public string? SgrsattAttsCode { get; set; }

    [Column("SGBSTDN_PROGRAM_1")]
    [StringLength(24)]
    public string? SgbstdnProgram1 { get; set; }

    [Column("EMAIL")]
    [StringLength(300)]
    public string? Email { get; set; }

    [Column("M_PHONE")]
    [StringLength(300)]
    public string? MPhone { get; set; }

    [Column("STU_SADAD_BAL", TypeName = "decimal(18, 0)")]
    public decimal? StuSadadBal { get; set; }

    [Column("ISHOLD")]
    public int? Ishold { get; set; }

    public bool? IsSigned { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? SignDate { get; set; }

    [Column("SHRLGPA_HOURS_PASSED", TypeName = "numeric(11, 3)")]
    public decimal? ShrlgpaHoursPassed { get; set; }

    [Column("SGBSTDN_TERM_CODE_ADMIT")]
    [StringLength(6)]
    public string? SgbstdnTermCodeAdmit { get; set; }

    [Column("SGBSTDN_MAJR_CODE_1")]
    [StringLength(4)]
    public string? SgbstdnMajrCode1 { get; set; }

    [Column("SGBSTDN_MAJR_CODE_CONC_1")]
    [StringLength(4)]
    public string? SgbstdnMajrCodeConc1 { get; set; }
}
