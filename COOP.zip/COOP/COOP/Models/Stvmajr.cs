﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace COOP.Models;

[Keyless]
[Table("STVMAJR")]
public partial class Stvmajr
{
    [Column("STVMAJR_CODE")]
    [StringLength(16)]
    public string? StvmajrCode { get; set; }

    [Column("STVMAJR_DESC")]
    [StringLength(120)]
    public string? StvmajrDesc { get; set; }

    [Column("STVMAJR_CIPC_CODE")]
    [StringLength(24)]
    public string? StvmajrCipcCode { get; set; }

    [Column("STVMAJR_VALID_MAJOR_IND")]
    [StringLength(4)]
    public string? StvmajrValidMajorInd { get; set; }

    [Column("STVMAJR_VALID_MINOR_IND")]
    [StringLength(4)]
    public string? StvmajrValidMinorInd { get; set; }

    [Column("STVMAJR_VALID_CONCENTRATN_IND")]
    [StringLength(4)]
    public string? StvmajrValidConcentratnInd { get; set; }

    [Column("STVMAJR_ACTIVITY_DATE", TypeName = "datetime")]
    public DateTime? StvmajrActivityDate { get; set; }

    [Column("STVMAJR_OCCUPATION_IND")]
    [StringLength(4)]
    public string? StvmajrOccupationInd { get; set; }

    [Column("STVMAJR_AID_ELIGIBILITY_IND")]
    [StringLength(4)]
    public string? StvmajrAidEligibilityInd { get; set; }

    [Column("STVMAJR_SYSTEM_REQ_IND")]
    [StringLength(4)]
    public string? StvmajrSystemReqInd { get; set; }

    [Column("STVMAJR_VR_MSG_NO", TypeName = "numeric(6, 0)")]
    public decimal? StvmajrVrMsgNo { get; set; }

    [Column("STVMAJR_DISP_WEB_IND")]
    [MaxLength(1)]
    public byte[]? StvmajrDispWebInd { get; set; }

    [Column("STVMAJR_SEVIS_EQUIV")]
    [StringLength(24)]
    public string? StvmajrSevisEquiv { get; set; }

    [Column("STVCOLL_CODE")]
    [StringLength(8)]
    public string? StvcollCode { get; set; }

    [Column("STVCOLL_DESC")]
    [StringLength(120)]
    public string? StvcollDesc { get; set; }

    [Column("STVCOLL_ADDR_STREET_LINE1")]
    [StringLength(300)]
    public string? StvcollAddrStreetLine1 { get; set; }

    [Column("STVCOLL_ADDR_STREET_LINE2")]
    [StringLength(300)]
    public string? StvcollAddrStreetLine2 { get; set; }

    [Column("STVCOLL_ADDR_STREET_LINE3")]
    [StringLength(300)]
    public string? StvcollAddrStreetLine3 { get; set; }

    [Column("STVCOLL_ADDR_CITY")]
    [StringLength(200)]
    public string? StvcollAddrCity { get; set; }

    [Column("STVCOLL_ADDR_STATE")]
    [StringLength(8)]
    public string? StvcollAddrState { get; set; }

    [Column("STVCOLL_ADDR_COUNTRY")]
    [StringLength(112)]
    public string? StvcollAddrCountry { get; set; }

    [Column("STVCOLL_ADDR_ZIP_CODE")]
    [StringLength(40)]
    public string? StvcollAddrZipCode { get; set; }

    [Column("STVCOLL_ACTIVITY_DATE", TypeName = "datetime")]
    public DateTime? StvcollActivityDate { get; set; }

    [Column("STVCOLL_SYSTEM_REQ_IND")]
    [StringLength(4)]
    public string? StvcollSystemReqInd { get; set; }

    [Column("STVCOLL_VR_MSG_NO", TypeName = "numeric(6, 0)")]
    public decimal? StvcollVrMsgNo { get; set; }

    [Column("STVCOLL_STATSCAN_CDE3")]
    [StringLength(24)]
    public string? StvcollStatscanCde3 { get; set; }

    [Column("STVCOLL_DICD_CODE")]
    [StringLength(12)]
    public string? StvcollDicdCode { get; set; }

    [Column("STVCOLL_HOUSE_NUMBER")]
    [StringLength(40)]
    public string? StvcollHouseNumber { get; set; }

    [Column("STVCOLL_ADDR_STREET_LINE4")]
    [StringLength(300)]
    public string? StvcollAddrStreetLine4 { get; set; }
}
