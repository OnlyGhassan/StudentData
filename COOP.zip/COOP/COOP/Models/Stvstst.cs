﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace COOP.Models;

[Keyless]
[Table("STVSTST")]
public partial class Stvstst
{
    [Column("STVSTST_CODE")]
    [StringLength(2)]
    public string StvststCode { get; set; } = null!;

    [Column("STVSTST_DESC")]
    [StringLength(30)]
    public string StvststDesc { get; set; } = null!;

    [Column("STVSTST_REG_IND")]
    [StringLength(1)]
    public string? StvststRegInd { get; set; }

    [Column("STVSTST_ACTIVITY_DATE", TypeName = "datetime")]
    public DateTime StvststActivityDate { get; set; }

    [Column("STVSTST_SYSTEM_REQ_IND")]
    [StringLength(1)]
    public string? StvststSystemReqInd { get; set; }

    [Column("STVSTST_CSTS_CODE")]
    [StringLength(15)]
    public string? StvststCstsCode { get; set; }

    [Column("STVSTST_CACT_CODE")]
    [StringLength(15)]
    public string? StvststCactCode { get; set; }
}
