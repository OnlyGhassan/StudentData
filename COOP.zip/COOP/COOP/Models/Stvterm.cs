﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace COOP.Models;

[Keyless]
[Table("STVTERM")]
public partial class Stvterm
{
    [Column("STVTERM_CODE")]
    [StringLength(6)]
    public string StvtermCode { get; set; } = null!;

    [Column("STVTERM_DESC")]
    [StringLength(30)]
    public string StvtermDesc { get; set; } = null!;

    [Column("STVTERM_START_DATE", TypeName = "datetime")]
    public DateTime StvtermStartDate { get; set; }

    [Column("STVTERM_END_DATE", TypeName = "datetime")]
    public DateTime StvtermEndDate { get; set; }

    [Column("STVTERM_FA_PROC_YR")]
    [StringLength(4)]
    public string? StvtermFaProcYr { get; set; }

    [Column("STVTERM_ACTIVITY_DATE", TypeName = "datetime")]
    public DateTime StvtermActivityDate { get; set; }

    [Column("STVTERM_FA_TERM")]
    [StringLength(1)]
    public string? StvtermFaTerm { get; set; }

    [Column("STVTERM_FA_PERIOD", TypeName = "numeric(2, 0)")]
    public decimal? StvtermFaPeriod { get; set; }

    [Column("STVTERM_FA_END_PERIOD", TypeName = "numeric(2, 0)")]
    public decimal? StvtermFaEndPeriod { get; set; }

    [Column("STVTERM_ACYR_CODE")]
    [StringLength(4)]
    public string StvtermAcyrCode { get; set; } = null!;

    [Column("STVTERM_HOUSING_START_DATE", TypeName = "datetime")]
    public DateTime StvtermHousingStartDate { get; set; }

    [Column("STVTERM_HOUSING_END_DATE", TypeName = "datetime")]
    public DateTime StvtermHousingEndDate { get; set; }

    [Column("STVTERM_SYSTEM_REQ_IND")]
    [StringLength(1)]
    public string? StvtermSystemReqInd { get; set; }

    [Column("STVTERM_TRMT_CODE")]
    [StringLength(1)]
    public string? StvtermTrmtCode { get; set; }

    [Column("STVTERM_FA_SUMMER_IND")]
    [StringLength(1)]
    public string? StvtermFaSummerInd { get; set; }
}
