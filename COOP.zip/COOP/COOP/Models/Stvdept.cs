﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace COOP.Models;

[Keyless]
[Table("STVdept")]
public partial class Stvdept
{
    [Column("STVDEPT_CODE")]
    [StringLength(255)]
    public string StvdeptCode { get; set; } = null!;

    [Column("STVDEPT_DESC")]
    [StringLength(255)]
    public string StvdeptDesc { get; set; } = null!;

    [Column("STVDEPT_ACTIVITY_DATE", TypeName = "datetime")]
    public DateTime StvdeptActivityDate { get; set; }

    [Column("STVDEPT_SYSTEM_REQ_IND")]
    [StringLength(255)]
    public string? StvdeptSystemReqInd { get; set; }

    [Column("STVDEPT_VR_MSG_NO")]
    [StringLength(255)]
    public string? StvdeptVrMsgNo { get; set; }

    [Column("STVCOLL_CODET")]
    [StringLength(2)]
    public string? StvcollCodet { get; set; }
}
