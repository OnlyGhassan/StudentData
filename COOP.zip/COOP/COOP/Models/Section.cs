﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace COOP.Models;

[Keyless]
public partial class Section
{
    [Column("SSBSECT_TERM_CODE")]
    [StringLength(6)]
    public string SsbsectTermCode { get; set; } = null!;

    [Column("SSBSECT_CRN")]
    [StringLength(5)]
    public string SsbsectCrn { get; set; } = null!;

    [Column("SSBSECT_SUBJ_CODE")]
    [StringLength(4)]
    public string SsbsectSubjCode { get; set; } = null!;

    [Column("SSBSECT_CRSE_NUMB")]
    [StringLength(5)]
    public string SsbsectCrseNumb { get; set; } = null!;

    [Column("SSBSECT_SEQ_NUMB")]
    [StringLength(3)]
    public string SsbsectSeqNumb { get; set; } = null!;

    [Column("SSBSECT_CRSE_TITLE")]
    [StringLength(30)]
    public string? SsbsectCrseTitle { get; set; }

    [Column("SSRRLVL_LEVL_CODE")]
    [StringLength(2)]
    public string? SsrrlvlLevlCode { get; set; }

    [Column("SSRRATT_ATTS_CODE")]
    [StringLength(4)]
    public string? SsrrattAttsCode { get; set; }

    [Column("SSRRCMP_CAMP_CODE")]
    [StringLength(3)]
    public string? SsrrcmpCampCode { get; set; }

    [Column("SSRRCOL_COLL_CODE")]
    [StringLength(2)]
    public string? SsrrcolCollCode { get; set; }

    [Column("SSBSECT_SSTS_CODE")]
    [StringLength(1)]
    public string SsbsectSstsCode { get; set; } = null!;

    [Column("SSBSECT_PTRM_START_DATE", TypeName = "datetime")]
    public DateTime? SsbsectPtrmStartDate { get; set; }

    [Column("SSBSECT_PTRM_END_DATE", TypeName = "datetime")]
    public DateTime? SsbsectPtrmEndDate { get; set; }

    [Column("SSBSECT_PTRM_WEEKS", TypeName = "numeric(3, 0)")]
    public decimal? SsbsectPtrmWeeks { get; set; }

    [Column("SYBPUAT_PIDM", TypeName = "numeric(8, 0)")]
    public decimal? SybpuatPidm { get; set; }
}
