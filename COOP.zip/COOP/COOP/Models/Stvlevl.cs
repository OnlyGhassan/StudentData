﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace COOP.Models;

[Keyless]
[Table("STVLEVL")]
public partial class Stvlevl
{
    [Column("STVLEVL_CODE")]
    [StringLength(2)]
    public string StvlevlCode { get; set; } = null!;

    [Column("STVLEVL_DESC")]
    [StringLength(30)]
    public string StvlevlDesc { get; set; } = null!;

    [Column("STVLEVL_ACTIVITY_DATE", TypeName = "datetime")]
    public DateTime StvlevlActivityDate { get; set; }

    [Column("STVLEVL_ACAD_IND")]
    [StringLength(1)]
    public string? StvlevlAcadInd { get; set; }

    [Column("STVLEVL_CEU_IND")]
    [StringLength(1)]
    public string StvlevlCeuInd { get; set; } = null!;

    [Column("STVLEVL_SYSTEM_REQ_IND")]
    [StringLength(1)]
    public string? StvlevlSystemReqInd { get; set; }

    [Column("STVLEVL_VR_MSG_NO", TypeName = "numeric(6, 0)")]
    public decimal? StvlevlVrMsgNo { get; set; }

    [Column("STVLEVL_EDI_EQUIV")]
    [StringLength(2)]
    public string? StvlevlEdiEquiv { get; set; }
}
