﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace COOP.Models;

[Keyless]
[Table("STVCAMP")]
public partial class Stvcamp
{
    [Column("STVCAMP_CODE")]
    [StringLength(3)]
    public string StvcampCode { get; set; } = null!;

    [Column("STVCAMP_DESC")]
    [StringLength(30)]
    public string? StvcampDesc { get; set; }

    [Column("STVCAMP_ACTIVITY_DATE", TypeName = "datetime")]
    public DateTime StvcampActivityDate { get; set; }

    [Column("STVCAMP_DICD_CODE")]
    [StringLength(3)]
    public string? StvcampDicdCode { get; set; }
}
