﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace COOP.Models;

[Keyless]
[Table("studentat")]
public partial class Studentat
{
    [Column("PIDM")]
    [StringLength(182)]
    public string Pidm { get; set; } = null!;

    [Column("ID")]
    [StringLength(182)]
    public string Id { get; set; } = null!;

    [Column("NAME")]
    [StringLength(182)]
    public string? Name { get; set; }

    [Column("TERM")]
    [StringLength(182)]
    public string Term { get; set; } = null!;

    [Column("CRN")]
    [StringLength(182)]
    public string Crn { get; set; } = null!;

    [Column("PTRM")]
    [StringLength(182)]
    public string? Ptrm { get; set; }

    [Column("SUBJ_CODE")]
    [StringLength(182)]
    public string SubjCode { get; set; } = null!;

    [Column("CRSE_NUMB")]
    [StringLength(182)]
    public string CrseNumb { get; set; } = null!;

    [Column("SEQ_NUMB")]
    [StringLength(182)]
    public string? SeqNumb { get; set; }

    [Column("GRADE")]
    [StringLength(182)]
    public string? Grade { get; set; }

    [Column("CAMP")]
    [StringLength(182)]
    public string? Camp { get; set; }
}
