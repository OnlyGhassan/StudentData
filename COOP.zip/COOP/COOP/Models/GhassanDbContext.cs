﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace COOP.Models;

public partial class GhassanDbContext : DbContext
{
    public GhassanDbContext()
    {
    }

    public GhassanDbContext(DbContextOptions<GhassanDbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<CccourseContract> CccourseContracts { get; set; }

    public virtual DbSet<DoctorDatum> DoctorData { get; set; }

    public virtual DbSet<Section> Sections { get; set; }

    public virtual DbSet<StudentDatum> StudentData { get; set; }

    public virtual DbSet<StudentSection> StudentSections { get; set; }

    public virtual DbSet<Studentat> Studentats { get; set; }

    public virtual DbSet<Stvatt> Stvatts { get; set; }

    public virtual DbSet<Stvcamp> Stvcamps { get; set; }

    public virtual DbSet<Stvcoll> Stvcolls { get; set; }

    public virtual DbSet<Stvdept> Stvdepts { get; set; }

    public virtual DbSet<Stvlevl> Stvlevls { get; set; }

    public virtual DbSet<Stvmajr> Stvmajrs { get; set; }

    public virtual DbSet<Stvresd> Stvresds { get; set; }

    public virtual DbSet<Stvrst> Stvrsts { get; set; }

    public virtual DbSet<Stvschd> Stvschds { get; set; }

    public virtual DbSet<Stvsst> Stvssts { get; set; }

    public virtual DbSet<Stvstst> Stvststs { get; set; }

    public virtual DbSet<Stvterm> Stvterms { get; set; }

    public virtual DbSet<Term> Terms { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        => optionsBuilder.UseSqlServer("Name=ConnectionStrings:Ghassan");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<CccourseContract>(entity =>
        {
            entity.Property(e => e.MailSent).HasDefaultValue(false);
        });

        modelBuilder.Entity<Stvmajr>(entity =>
        {
            entity.Property(e => e.StvmajrDispWebInd).IsFixedLength();
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
