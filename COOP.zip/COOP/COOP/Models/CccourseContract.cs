﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace COOP.Models;

[Table("CCCourseContract")]
public partial class CccourseContract
{
    [Key]
    public int Id { get; set; }

    [StringLength(10)]
    public string Termcode { get; set; } = null!;

    [StringLength(10)]
    public string? DocNum { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime CreatedDate { get; set; }

    public bool IsApproved { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? ApproveDate { get; set; }

    public bool IsDeleted { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? EditDate { get; set; }

    [StringLength(6)]
    public string Crn { get; set; } = null!;

    [StringLength(6)]
    public string SubjCode { get; set; } = null!;

    [StringLength(6)]
    public string CrseNum { get; set; } = null!;

    [Column("CountST")]
    public int CountSt { get; set; }

    [StringLength(300)]
    public string? Title { get; set; }

    [StringLength(10)]
    public string? Atts { get; set; }

    public int UnitsNum { get; set; }

    public int DoctorId { get; set; }

    public int? IdKauEvent { get; set; }

    public bool IsReviwed { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? ReviweDate { get; set; }

    [Column("ReviewBY")]
    public int? ReviewBy { get; set; }

    public string? FilePath { get; set; }

    [StringLength(10)]
    public string? LevelType { get; set; }

    public bool? MailSent { get; set; }

    [StringLength(50)]
    public string? PrimaryIndecator { get; set; }
}
