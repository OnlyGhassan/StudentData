﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace COOP.Models;

[Keyless]
[Table("STVRESD")]
public partial class Stvresd
{
    [Column("STVRESD_CODE")]
    [StringLength(1)]
    public string StvresdCode { get; set; } = null!;

    [Column("STVRESD_DESC")]
    [StringLength(30)]
    public string? StvresdDesc { get; set; }

    [Column("STVRESD_IN_STATE_IND")]
    [StringLength(1)]
    public string? StvresdInStateInd { get; set; }

    [Column("STVRESD_ACTIVITY_DATE", TypeName = "datetime")]
    public DateTime StvresdActivityDate { get; set; }

    [Column("STVRESD_SYSTEM_REQ_IND")]
    [StringLength(1)]
    public string? StvresdSystemReqInd { get; set; }

    [Column("STVRESD_VR_MSG_NO", TypeName = "numeric(6, 0)")]
    public decimal? StvresdVrMsgNo { get; set; }

    [Column("STVRESD_DISP_WEB_IND")]
    [MaxLength(1)]
    public byte[]? StvresdDispWebInd { get; set; }

    [Column("STVRESD_EDI_EQUIV")]
    [StringLength(1)]
    public string? StvresdEdiEquiv { get; set; }
}
