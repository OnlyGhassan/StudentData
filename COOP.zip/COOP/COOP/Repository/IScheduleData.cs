using COOP.Models;
namespace COOP.Repository;

public interface IScheduleData
{ 
    List<ScheduleInfo> GetScheduleInfo(string id);
}