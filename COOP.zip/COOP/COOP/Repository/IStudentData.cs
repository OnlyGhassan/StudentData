    using COOP.Models;
    namespace COOP.Repository;

    public interface IStudentData
    {
        IEnumerable<StudentDatum> getAllData();
        StudentInfo getStudentById(string id);
    }