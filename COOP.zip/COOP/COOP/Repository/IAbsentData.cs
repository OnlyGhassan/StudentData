using COOP.Models;
namespace COOP.Repository;

public interface IAbsentData
{ 
    List<AbsentInfo> getAbsentById(string id);
}