using COOP;
using COOP.Models;
using COOP.Repository;

public class SheduleDataRepository : IScheduleData
{

    private readonly GhassanDbContext _DbContext;

    public SheduleDataRepository(GhassanDbContext DbContext)
    {
        _DbContext = DbContext;
    }

    public List<ScheduleInfo> GetScheduleInfo(string id)
    {
        StudentDatum? studentDatum = _DbContext.StudentData.FirstOrDefault(x => x.SpridenId == id);
         List<ScheduleInfo> schedules =   new List<ScheduleInfo>();
        if (studentDatum != null)
        {
          
            schedules.Add( new ScheduleInfo()
            {
            Term = new DateOnly(2024, 9, 1),
            Name = "Advanced Data Analytics",
            Dept = "Computer Science",
            Course_No = "CSCI404",
            Section = "01",
            CRN = "12345",
            Instructor_ID = "987654",
            TeacherName = "Dr. Jane Smith",
            Status = "Active",
            LastModificationDate = DateTime.Now.AddDays(-3),
            AddedDate = DateTime.Now.AddMonths(-1),
            SectionSchedule = new DateTime(2024, 9, 1, 10, 0, 0),
            Time = new DateTime(2024, 9, 1, 17, 0, 0)

            });
        }

       return schedules;
    }
}
