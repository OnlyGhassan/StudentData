using COOP;
using COOP.Models;
using COOP.Repository;

public class StudentDataRepository : IStudentData
{
    private readonly GhassanDbContext _DbContext;

    public StudentDataRepository(GhassanDbContext DbContext)
    {
        _DbContext = DbContext;
    }
    public IEnumerable<StudentDatum> getAllData() // dont use 
    {
        return _DbContext.StudentData.Where(x => x.SpridenId.StartsWith("15")).ToList();
    }

    public StudentInfo getStudentById(string id)
    {
        StudentDatum? studentDatum = _DbContext.StudentData.FirstOrDefault(x => x.SpridenId == id);
        if (studentDatum != null)
        {
            return new StudentInfo()
            {

               StudentNo = ""+studentDatum.SpridenId,
               StudentID = ""+studentDatum.SpridenId,
               StudentPIDM = ""+studentDatum.SpridenPidm,
               FullName = studentDatum.SpridenFirstName+ " " + studentDatum.SpridenMi + " " + studentDatum.SpridenLastName,
               IDNumber = ""+studentDatum.SpbpersSsn,
               College = studentDatum.SgbstdnCollCode1,
               CampusTitle = studentDatum.SgbstdnCampCode,
               DeptTitle = studentDatum.SgbstdnDeptCode,
               Status = studentDatum.SgbstdnStypCode
               

            };
        }
        return new StudentInfo();
    }
}