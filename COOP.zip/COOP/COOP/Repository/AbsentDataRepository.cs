using COOP;
using COOP.Models;
using COOP.Repository;

public class AbsentDataRepository : IAbsentData
{

    private readonly GhassanDbContext _DbContext;

    public AbsentDataRepository(GhassanDbContext DbContext)
    {
        _DbContext = DbContext;
    }

    public List<AbsentInfo> getAbsentById(string id)
    {
        StudentDatum? studentDatum = _DbContext.StudentData.FirstOrDefault(x => x.SpridenId == id);
        List<AbsentInfo> absents =   new List<AbsentInfo>();

        if (studentDatum != null)
        {
            absents.Add( new AbsentInfo()
            {
            Term = new DateTime(2023, 05, 02),
            Crn = "1234588",
            Course = "CSCI404",
            Title = "Advanced Data Analytics",
            Section = "01",
            AbsentCount = 3,
            DAYS = new DateTime(2023, 10, 9, 15, 25, 21),

            });
        }
        return absents;
    }
}
