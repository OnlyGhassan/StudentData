using COOP.Models;
using COOP.Repository;
using Microsoft.AspNetCore.Mvc;

namespace COOP.Controllers;

[ApiController]
[Route("[controller]")]
public class studentController : ControllerBase
{

    // private IStudentData studentRepository;

    //   public studentController()
    //   {
    //      studentRepository = new StudentDataRepository(new GhassanDbContext());
    //   }

    private readonly ILogger<studentController> _logger;
    private readonly IScheduleData _ScheduleDataRepo;
    private readonly IStudentData _StudentData;
    private readonly IAbsentData _AbsentData;

    public studentController(ILogger<studentController> logger, IScheduleData scheduleInfo, IStudentData studentData, IAbsentData absentData)
    {
        _logger = logger;
        _ScheduleDataRepo = scheduleInfo;
        _StudentData = studentData;
        _AbsentData = absentData;
    }

    [HttpGet]
    [Route("StudentData")]
    public async Task<StudentInfo> GetStudent(string studentId)
    {

        return _StudentData.getStudentById(studentId);
    }


    [HttpGet]
    [Route("ScheduleData")]
    public async Task<List<ScheduleInfo>> GetSchedule(string studentId)
    {

        return _ScheduleDataRepo.GetScheduleInfo(studentId);
    }
    [HttpGet]
    [Route("AbsentData")]
    public async Task<List<AbsentInfo>> GetAbsent(string studentId)
    {

        return _AbsentData.getAbsentById(studentId);
    }

}